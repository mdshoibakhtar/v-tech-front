import React from "react"
import WaterForHealth from "../../components/waterForHealth/WaterForHealth"

function WaterForHealthPage() {
    return (
        <>
        <WaterForHealth/>
        </>
    )
}
export default WaterForHealthPage