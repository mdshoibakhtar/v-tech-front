import React from "react";

const SocialResp = () => {
  return (
    <>
      <section className="socialResp">
        <div className="container">
          <div className="innerSocialResp">
            <h3>CORPORATE SOCIAL RESPONSIBILITY</h3>
            <a href="#" className="btn btn-primary">DOWNLOAD</a>
          </div>
        </div>
      </section>
    </>
  );
};

export default SocialResp;
